<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class help extends Model
{
    protected $fillable = [
        'user_id', 'transaction' , 'status', 'amount',
    ];

    public function person() {
        return $this->belongsTo('App\User', 'user_id');
    }
    
    public function orders() {
        return $this->hasOne('App\order', 'product_id');
    }
}
