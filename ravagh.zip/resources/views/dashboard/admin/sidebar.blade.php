<x-sidebar-item title="داشبورد" icon="fas fa-tachometer-alt" route="dashboard.admin.index" />
<x-sidebar-item title="مدیریت محصول ها" icon="fas fa-cart-plus" route="dashboard.admin.product.manage" />
<x-sidebar-item title="مدیریت فیلم ها" icon="fas fa-cart-plus" route="dashboard.admin.movies.manage" />
<x-sidebar-item title="مدیریت برند ها" icon="fas fa-store-alt" route="dashboard.admin.brands.manage" />
<x-sidebar-item title="مدیریت ویژگی" icon="fas fa-folder" route="dashboard.admin.colors.manage" />
<x-sidebar-item title="مدیریت تخفیف" icon="fas fa-cash-register" route="dashboard.admin.discount.manage" />
<x-sidebar-item title="لیست دسته‌بندی‌ها" icon="fas fa-tags" route="dashboard.admin.categories.index" />
<x-sidebar-item title="مدیریت مطالب" icon="fas fa-edit" route="dashboard.admin.news.manage" />
<x-sidebar-item title="مدیریت نظرات" icon="fas fa-folder" route="dashboard.admin.comment.manage" />
<x-sidebar-item title="مدیریت تماس" icon="fas fa-folder" route="dashboard.admin.contact.manage" />
<x-sidebar-item title="مدیریت بنر ها" icon="fas fa-money-check-alt" route="dashboard.admin.slider-items.index" />
<x-sidebar-item title="مدیریت اشتراک" icon="far fa-handshake" route="dashboard.admin.subscription.manage" />
<x-sidebar-item title="مدیریت پروموشن" icon="far fa-handshake" route="dashboard.admin.promotion.manage" />
<x-sidebar-item title="مدیریت کاربران" icon="fas fa-users" route="dashboard.admin.users.index" />
<x-sidebar-item title="مدیریت اعلان ها" icon="fas fa-edit" route="dashboard.admin.notification.manage" />
<x-sidebar-item title="مدیریت فایل ها" icon="fas fa-folder" route="dashboard.admin.uploader.manage" />
<x-sidebar-item title="مدیریت فروش" icon="far fa-handshake" route="dashboard.admin.orders.manage" />
<x-sidebar-item title="تراکنش ها" icon="fas fa-money-check-alt" route="dashboard.admin.transaction.manage" />
<x-sidebar-item title="پاک کردن کش" icon="fas fa-money-check-alt" route="dashboard.admin.clear-cache" />