<!--Footer Area-->
<footer class="footer-area section-padding-2 dark-overlay jb_cover" style="background: url('http://packprinting.info/images/foooter.gif') no-repeat center / cover; text-align: right; direction: rtl;">
    <div class="container">
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="footer-widget jb_cover">
                    <a href="#" class="footer-logo"><img src="{{asset('assets/images/footerlogo.png')}}" alt="لوگوی فوتر ماهنامه صنایع چاپ و بسته بندی"></a>
                    <p>مجله بین المللی در زمینه چاپ و بسته بندی و صنایع وابسته </p>
                    <p>تلفن :09371016366</p>
                    <div class="social">
                        <a href="#" class="cl-facebook"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="cl-twitter"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="cl-youtube"><i class="fab fa-youtube-play"></i></a>
                        <a href="#" class="cl-pinterest"><i class="fab fa-pinterest-p"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="footer-widget jb_cover">
                    <h3>مجله الکترونیکی</h3>
                      <div class="site-category">
                          <ul>
                              <li><a href="http://packprinting.ir/podcast"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>پادکست </a> </li>
                              <li><a href="http://packprinting.ir/magazine"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>فروش آنلاین مجله</a></li>
                              <li><a href="http://packprinting.ir/subscribe"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>فرم اشتراک آنلاین مجله</a> </li>
                              <li><a href="#"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>دنیای بسته بندی </a> </li>
                              <li><a href="http://packprinting.ir/news"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>اخبار</a> </li>
                              <li><a href="http://packprinting.ir/article"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>مقالات</a></li>
                              <li><a href="http://packprinting.ir/picnews"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>گزارش تصویری</a></li>
                              <li><a href="http://packprinting.ir/gallery"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>گالری تصاویر</a></li>
                              <li><a href="http://packprinting.ir/exhibition"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>برنامه نمایشگاهی  </a></li>
                              <li><a href="http://packprinting.ir/specialexhibition"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>برنامه نمایشگاهی مجله </a></li>
                          </ul>
                      </div>
                  </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="footer-widget jb_cover">
                  <h3>برندینگ و بازاریابی</h3>
                    <div class="site-category">
                        <ul>
                            <li><a href="#"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>چاپ آگهی و رپرتاژ </a> </li>
                            <li><a href="#"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>درج آگهی در سایت و فضای مجازی</a></li>
                            <li><a href="#"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>طراحی سایت </a> </li>
                            <li><a href="#"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>ایمیل انبوه و تبلیغات گوگل </a> </li>
                            <li><a href="#"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>خدمات چاپ و بسته بندی</a> </li>
                            <li><a href="#"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>عکاسی و ساخت تیزر </a></li>
                        </ul>
                    </div>
                </div>
                </div>

            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="footer-widget jb_cover">
                     <h3 >بانک اطلاعاتی</h3>
                    <div class="site-category">
                        <ul>
                            <li><a href="http://directory.packprinting.ir"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>صفحه داینامیک اختصاصی </a> </li>
                        </ul>
                    </div>
                    <h3 style="margin-top:29px;">فروشگاه (B2B)</h3>
                    <div class="site-category">
                        <ul>
                            <li><a href="#"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>خریداران کالا </a> </li>
                            <li><a href="#"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>فروشندگان کالا</a></li>
                        </ul>
                    </div>
                   <h3 style="margin-top:29px;">پل ارتباطی</h3>
                    <div class="site-category">
                        <ul>
                            <li><a href="http://packprinting.ir/contact"><i class="fas fa-hand-point-left" style="padding-left: 5px;"></i>تماس با ما </a> </li>
                        </ul>
                    </div>
            </div>
        </div>
    </div>
</footer><!--/Footer Area-->

<!--Copyright-->
<div class="copyright jb_cover">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                <a href="http://salarshirkhani.ir"><p>© salarshirkhani</p></a>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
             <p>تمامی حقوق نزد چاپ و بسته بندی محفوظ است</p>
            </div>
        </div>
    </div>
</div><!--Copyright-->



<!-- chat box Wrapper end -->
<!--custom js files-->
<script src="{{asset('assets/js/jquery-3.3.1.min.js')}}"></script>
<script src="{{asset('assets/js/bootstrap.min.js')}}"></script>
<script src="{{asset('assets/js/modernizr.js')}}"></script>
<script src="{{asset('assets/js/jquery.menu-aim.js')}}"></script>
<script src="{{asset('assets/js/plugin.js')}}"></script>
<script src="{{asset('assets/js/owl.carousel.js')}}"></script>
<script src="{{asset('assets/js/jquery-ui.js')}}"></script>
<script src="{{asset('assets/js/jquery.countTo.js')}}"></script>
<script src="{{asset('assets/js/jquery.magnific-popup.js')}}"></script>
<script src="{{asset('assets/js/dropify.min.js')}}"></script>
<script src="{{asset('assets/js/jquery.inview.min.js')}}"></script>
<script src="{{asset('assets/js/jquery.nice-select.min.js')}}"></script>
<script src="{{asset('assets/js/imagesloaded.pkgd.min.js')}}"></script>
<script src="{{asset('assets/js/isotope.pkgd.min.js')}}"></script>
<script src="{{asset('assets/js/custom.js')}}"></script>
