<head>
    <meta charset="utf-8" />
    <title>ماهنامه صنایع چاپ و بسته بندی| بانک اطلاعاتی</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta name="description" content="بانک اطلاعاتی ماهنامه صنایع چاپ و بسته بندی " />
    <meta name="keywords" content="|بانک اطلاعاتی بسته بندی|ماهنامه صنایع چاپ و بسته بندی|چاپ|بسته بندی|بانک اطلاعاتی چاپ" />
    <meta name="author" content="salarshirkhani.ir" />
    <meta name="MobileOptimized" content="320" />
    <!--Template style -->
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/animate.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/bootstrap.min.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/fonts.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/flaticon.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/owl.carousel.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/owl.theme.default.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/dropify.min.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/jquery-ui.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/magnific-popup.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/nice-select.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/reset.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/style.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/responsive.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{asset('assets/css/font-awesome.css')}}" />
    <!--favicon-->
    <link rel="shortcut icon" type="image/png" href="{{asset('assets/images/favicon.png')}}" />

    <!-- Themify icons -->
    <link rel="stylesheet" type="text/css" href="http://packprinting.info/css/themify-icons.css" />
    {{ $styles ?? '' }}
</head>
