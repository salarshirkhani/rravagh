<div class="news_letter_wrapper jb_cover">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="job_newsletter_wrapper jb_cover">
                    <div class="jb_newslwtteter_left">
                        <h2> ثبت نام کنید</h2>
                        <p>اگر می خواهید از امکانات متنوع سایت ماهنامه صنایع چاپ و بسته بندی برخوردار شوید در سایت ثبت نام کنید</p>
                    </div>
                    <div class="jb_newslwtteter_button">
                        <div class="header_btn search_btn news_btn jb_cover">

                            <a href="#">تایید</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div></div></div>