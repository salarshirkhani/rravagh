@extends('errors::minimal')

@section('title', __('Server Error'))
@section('code', 'کتاب جنگ')
@section('message', __('مشکلی در اجرای عملیات شما پیش آمده است'))
